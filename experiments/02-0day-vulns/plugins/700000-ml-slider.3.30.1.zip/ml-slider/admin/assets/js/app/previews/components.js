/**
 * Load all the components. needed for the app
 */

import Vue from 'vue'
import SweetModal from 'sweet-modal-vue/src/plugin.js'

Vue.use(SweetModal)

export default { SweetModal }
