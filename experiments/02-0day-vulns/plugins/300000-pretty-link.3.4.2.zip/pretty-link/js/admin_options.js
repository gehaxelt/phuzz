jQuery(document).ready(function($) {
  $('.prli-color-picker').wpColorPicker();
});

