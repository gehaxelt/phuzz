<?php
namespace ShortPixel;

?>

<div id="spioSettingsModalShade" class="spio-modal-shade" style="display:none;"></div>
			 <div id="spioSettingsModal" class="spio-modal spio-hide" style="min-width:610px;margin-left:-305px;">
					 <div class="spio-modal-title">
							 <button type="button" class="spio-close-help-button" onclick="jQuery.spioHelpClose()">&times;</button>
					 </div>
					 <div class="spio-modal-body" style="height:auto;min-height:400px;padding:0;">

					 </div>
			 </div>
