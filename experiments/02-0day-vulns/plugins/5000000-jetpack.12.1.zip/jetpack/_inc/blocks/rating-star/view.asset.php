<?php return array('dependencies' => array('wp-polyfill'), 'version' => '431d4fc34def8d462a46');
