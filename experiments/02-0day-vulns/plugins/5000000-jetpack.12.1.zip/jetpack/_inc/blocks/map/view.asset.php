<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'b936bf337430eda2dd8b');
