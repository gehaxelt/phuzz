<?php return array('dependencies' => array('wp-polyfill'), 'version' => '19f8442b579ba4243436');
