<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'd433cd597ef37b7bd6e4');
