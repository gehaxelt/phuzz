<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '6f28cff8c5df7fd8fc16');
