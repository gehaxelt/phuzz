<?php return array('dependencies' => array('wp-polyfill'), 'version' => '2c8df870e4f9242e39f3');
