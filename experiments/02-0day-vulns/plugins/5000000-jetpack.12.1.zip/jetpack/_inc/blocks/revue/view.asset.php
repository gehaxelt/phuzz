<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '34161b4df3bd61df491d');
