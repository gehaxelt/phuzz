<?php return array('dependencies' => array('wp-polyfill'), 'version' => '88cc42f3d74bf0571573');
