<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'ed5eba808dc58a516802');
