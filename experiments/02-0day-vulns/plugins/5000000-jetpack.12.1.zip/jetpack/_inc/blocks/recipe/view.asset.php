<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '051a0c618ec2c5577d3c');
