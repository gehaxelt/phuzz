<?php return array('dependencies' => array('wp-polyfill'), 'version' => '8f36e745d927eeb2a83d');
