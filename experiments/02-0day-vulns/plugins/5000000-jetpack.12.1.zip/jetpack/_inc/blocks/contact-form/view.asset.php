<?php return array('dependencies' => array('wp-polyfill'), 'version' => '50b8c08e24df72cf9f4a');
