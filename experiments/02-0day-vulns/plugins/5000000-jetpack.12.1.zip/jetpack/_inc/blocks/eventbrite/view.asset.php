<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'c84ab43039a3d054b53a');
