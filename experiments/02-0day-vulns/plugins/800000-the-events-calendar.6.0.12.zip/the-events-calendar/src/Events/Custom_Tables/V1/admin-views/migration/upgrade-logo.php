<img
	class="tec-ct1-upgrade__logo"
	src="<?php echo esc_url( tribe_resource_url( 'images/icons/horns.svg', false, null, \Tribe__Main::instance() ) ); ?>"
	alt="<?php esc_attr_e( 'The Events Calendar product suite logo', 'the-events-calendar' ); ?>"
/>
