<?php

namespace Nextend\SmartSlider3\Application\Admin\Slides;

/**
 * @var $this ViewAjaxSlideBox
 */


$this->renderSlideBlock();