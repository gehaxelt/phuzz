<?php return array('dependencies' => array('wp-i18n'), 'version' => '396e6418a267ebf13962');
