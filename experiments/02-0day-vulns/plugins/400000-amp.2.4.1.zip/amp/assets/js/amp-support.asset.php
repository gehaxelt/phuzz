<?php return array('dependencies' => array('lodash', 'wp-api-fetch'), 'version' => 'c87b582d766036a876c5');
