<?php return array('dependencies' => array(), 'version' => 'e0622116543e409e9f46');
