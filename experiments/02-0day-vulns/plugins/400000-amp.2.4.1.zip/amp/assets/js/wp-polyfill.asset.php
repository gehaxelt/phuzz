<?php return array('dependencies' => array(), 'version' => 'bd7299b713fc8a73f74f');
