<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'abd82389632931cde408');
