<?php return array('dependencies' => array('lodash', 'wp-dom-ready', 'wp-i18n'), 'version' => 'f6967cdb6ff8055f7af9');
