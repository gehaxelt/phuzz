<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '63014822ef6a3a634d50');
