<?php return array('dependencies' => array('wp-i18n'), 'version' => '27ef6c89057c08d33752');
