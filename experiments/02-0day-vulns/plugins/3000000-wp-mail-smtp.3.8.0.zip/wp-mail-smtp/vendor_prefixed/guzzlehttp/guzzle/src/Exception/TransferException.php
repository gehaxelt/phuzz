<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \WPMailSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
