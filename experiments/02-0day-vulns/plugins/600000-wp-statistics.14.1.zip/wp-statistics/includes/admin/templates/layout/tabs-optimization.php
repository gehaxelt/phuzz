<ul class="tabs">
    <li class="tab-link current" data-tab="resources"><?php _e('Resources/Information', 'wp-statistics'); ?></li>
    <li class="tab-link" data-tab="export"><?php _e('Export', 'wp-statistics'); ?></li>
    <li class="tab-link" data-tab="purging"><?php _e('Purging', 'wp-statistics'); ?></li>
    <li class="tab-link" data-tab="database"><?php _e('Database', 'wp-statistics'); ?></li>
    <li class="tab-link" data-tab="updates"><?php _e('Updates', 'wp-statistics'); ?></li>
    <li class="tab-link" data-tab="historical"><?php _e('Historical', 'wp-statistics'); ?></li>
</ul>
