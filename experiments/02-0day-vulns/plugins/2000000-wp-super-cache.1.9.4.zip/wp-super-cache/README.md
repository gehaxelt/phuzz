# super-cache

A very fast caching engine for WordPress that produces static html files.

## How to install super-cache

### Installation From Git Repo

## Contribute

## Get Help

Support is handled via the .org support forums.

## Security

Need to report a security vulnerability? Go to [https://automattic.com/security/](https://automattic.com/security/) or directly to our security bug bounty site [https://hackerone.com/automattic](https://hackerone.com/automattic).

## License

super-cache is licensed under [GNU General Public License v2 (or later)](./LICENSE.txt)
