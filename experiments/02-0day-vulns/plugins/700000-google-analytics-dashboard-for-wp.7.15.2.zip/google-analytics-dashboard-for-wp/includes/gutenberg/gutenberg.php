<?php

$base = ExactMetrics();
require_once plugin_dir_path( $base->file ) . '/includes/gutenberg/headline-tool/headline-tool.php';
require_once plugin_dir_path( $base->file ) . '/includes/gutenberg/register-scripts.php';
