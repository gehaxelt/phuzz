a:3:{i:0;s:5:"isn't";i:1;s:6:"aren't";i:2;s:3:"not";}
