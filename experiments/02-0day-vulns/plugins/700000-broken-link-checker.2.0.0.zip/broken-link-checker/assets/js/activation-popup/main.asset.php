<?php return array('dependencies' => array('react', 'wp-element'), 'version' => 'a1b5e4de8fdef5fc0998');
