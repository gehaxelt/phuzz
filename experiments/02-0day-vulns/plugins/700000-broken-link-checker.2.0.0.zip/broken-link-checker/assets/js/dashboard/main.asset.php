<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '535b5099d408f9a65e03');
