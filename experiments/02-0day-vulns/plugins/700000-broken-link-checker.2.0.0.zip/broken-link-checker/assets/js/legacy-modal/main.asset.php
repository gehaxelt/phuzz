<?php return array('dependencies' => array('react', 'wp-element'), 'version' => 'f96fa56f88ef39ca38c7');
