<?php
	echo 'dummy page.';

