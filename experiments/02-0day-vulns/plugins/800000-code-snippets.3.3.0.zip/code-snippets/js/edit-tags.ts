import { loadSnippetTagEditor } from './edit/tags'

loadSnippetTagEditor()
