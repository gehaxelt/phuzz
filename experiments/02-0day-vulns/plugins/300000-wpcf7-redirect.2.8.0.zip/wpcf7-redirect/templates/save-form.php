<?php
/**
 * Please save your form message
 */

defined( 'ABSPATH' ) || exit;
?>

<fieldset>
	<div class="fields-wrap field-wrap-page-id">
		<div class="tab-wrap">
			<div class="wpcf7r-tab-wrap-inner">
				<div data-tab-inner>
					<h3>
						<?php _e( 'Please save your form', 'wpcf7-redirect' ); ?>
					</h3>
				</div>
			</div>
		</div>
	</div>
</fieldset>
