# PDF Invoices & Packing Slips for WooCommerce
Welcome to the PDF Invoices & Packing Slips for WooCommerce repository on GitHub. Here you can browse the source, look at open issues and keep track of development.

If you are not a developer, please use the [PDF Invoices & Packing Slips for WooCommerce support forum](http://wordpress.org/support/plugin/woocommerce-pdf-invoices-packing-slips) on WordPress.org.

## Support
This repository is not suitable for support. Please don't use our issue tracker for support requests, but for core plugin issues only. Support can take place in the appropriate channels:

* The [PDF Invoices & Packing Slips for WooCommerce support forum](http://wordpress.org/support/plugin/woocommerce-pdf-invoices-packing-slips) on WordPress.org.
* [WP Overnight Premium support](https://wpovernight.com/contact/) for customers who have purchased themes or plugins.

Support requests in issues on this repository will be closed on sight.