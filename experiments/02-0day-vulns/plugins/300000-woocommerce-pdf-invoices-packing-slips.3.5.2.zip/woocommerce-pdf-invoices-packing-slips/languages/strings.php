<?php
exit;
__( 'VAT', 'woocommerce-pdf-invoices-packing-slips' );
__( 'Tax rate', 'woocommerce-pdf-invoices-packing-slips' );
__( 'Payment method', 'woocommerce-pdf-invoices-packing-slips' );
__( 'Shipping method', 'woocommerce-pdf-invoices-packing-slips' );
__( 'Send email', 'woocommerce-pdf-invoices-packing-slips' );
