<?php
// phpcs:ignoreFile
/**
 * Facebook for WooCommerce.
 */

namespace WooCommerce\Facebook\Framework\Plugin;

defined( 'ABSPATH' ) or exit;

/**
 * Plugin Framework Exception - generic Exception
 */
class Exception extends \Exception {}
