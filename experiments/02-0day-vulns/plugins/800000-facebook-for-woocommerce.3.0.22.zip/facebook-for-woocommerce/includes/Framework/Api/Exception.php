<?php
/**
 * Facebook for WooCommerce.
 */

namespace WooCommerce\Facebook\Framework\Api;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin Framework API Exception - generic API Exception
 */
class Exception extends \WooCommerce\Facebook\Framework\Plugin\Exception { }
