<?php

namespace PostSMTP\Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \PostSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
