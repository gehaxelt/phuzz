<?php

namespace PostSMTP\Vendor\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \PostSMTP\Vendor\GuzzleHttp\Exception\BadResponseException
{
}
