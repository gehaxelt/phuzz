<?php

namespace PostSMTP\Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends \PostSMTP\Vendor\GuzzleHttp\Exception\RequestException
{
}
