<?php

namespace ProfilePress\Core\Themes\Shortcode;


interface EditProfileThemeInterface extends RegistrationThemeInterface
{
}