<div class="ppress-content-restriction-shortcode-doc">
    <p>
        <?php
        printf(
            esc_html__('Want to control the visibility of Elementor sections, containers and widgets based on user roles, logged-in status and membership plans? %sLearn how to%s', 'wp-user-avatar'),
            '<a target="_blank" href="https://profilepress.com/article/restrict-elementor-sections-widgets/">', '</a>'
        ); ?>
    </p>
</div>