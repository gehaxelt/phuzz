<?php

namespace ProfilePress\Core\Membership\Models\Coupon;

class CouponUnit
{
    const PERCENTAGE = 'percent';
    const FLAT = 'flat';
}