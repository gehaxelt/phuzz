<?php

namespace ProfilePress\Core\Membership\Models;

interface ModelInterface
{
    public function exists();
}