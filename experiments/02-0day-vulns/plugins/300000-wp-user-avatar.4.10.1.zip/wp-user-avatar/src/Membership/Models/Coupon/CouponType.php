<?php

namespace ProfilePress\Core\Membership\Models\Coupon;

class CouponType
{
    const RECURRING = 'recurring';
    const ONE_TIME = 'one_time';
}