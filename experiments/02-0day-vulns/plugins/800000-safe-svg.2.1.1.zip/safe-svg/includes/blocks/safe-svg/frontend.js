/* global safe-svg_personalizer_params */
/* eslint-disable camelcase */
import './frontend.scss';
