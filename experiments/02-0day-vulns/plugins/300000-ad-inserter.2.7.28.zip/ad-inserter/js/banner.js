window.ad_banner=true;
