var ai_cookie_js = true;
var ai_block_class_def = 'AI_FUNCT_GET_BLOCK_CLASS_NAME';

