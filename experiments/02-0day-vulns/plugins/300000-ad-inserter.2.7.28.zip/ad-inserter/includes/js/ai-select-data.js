var ai_selection_block    = "AI_POST_HTML_ELEMENT_SELECTION";
var ai_settings_selector  = "AI_POST_SELECTOR";
var ai_settings_input     = "AI_POST_INPUT";

