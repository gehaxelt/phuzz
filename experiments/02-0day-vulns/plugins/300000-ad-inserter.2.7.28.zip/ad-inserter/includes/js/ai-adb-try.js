// minimize whitespace only
try {
  var ai_adb = window.jQuery && window.jQuery.fn, ai_check = ai_adb, ai_adb_overlay = String (ai_check).charCodeAt (ai_adb), ai_check_block = ai_adb;
}
catch (e) {
  AI_ADB_HTML=1;

  document.body.prepend (
    Object.assign (document.createElement ('AI_ADB_MSG_TAG'), {
      style: "AI_ADB_MSG_STYLE",
      innerHTML: "AI_ADB_MSG_HTML"
    })
  );

  AI_ADB_HTML=2
}
