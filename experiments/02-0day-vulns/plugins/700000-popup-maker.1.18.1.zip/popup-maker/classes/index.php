<?php
/**
 * Silence is golden.
 *
 * @package   PUM
 * @copyright Copyright (c) 2023, Code Atlantic LLC
 */
