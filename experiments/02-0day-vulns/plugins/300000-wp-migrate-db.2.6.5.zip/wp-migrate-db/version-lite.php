<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db']['version'] = '2.6.5';
