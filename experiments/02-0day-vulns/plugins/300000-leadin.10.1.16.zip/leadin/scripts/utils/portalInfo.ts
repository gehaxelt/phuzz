import {
  portalDomain,
  portalId,
  accountName,
  portalEmail,
} from '../constants/leadinConfig';

export const leadinGetPortalInfo = () => ({
  portalDomain,
  portalId,
  portalEmail,
  accountName,
});
