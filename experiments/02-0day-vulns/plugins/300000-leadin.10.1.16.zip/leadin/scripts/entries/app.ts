import { initAppOnReady } from '../utils/appUtils';
import { renderIframeApp } from '../iframe/IframeApp';

initAppOnReady(renderIframeApp);
