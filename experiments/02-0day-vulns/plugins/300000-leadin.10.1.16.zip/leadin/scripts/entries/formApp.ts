import { initAppOnReady } from '../utils/appUtils';
import { renderIframeApp } from '../iframe/FormIframeApp';

initAppOnReady(renderIframeApp);
