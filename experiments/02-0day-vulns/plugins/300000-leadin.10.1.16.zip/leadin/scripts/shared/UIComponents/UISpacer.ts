import { styled } from '@linaria/react';

export default styled.div`
  height: 30px;
`;
