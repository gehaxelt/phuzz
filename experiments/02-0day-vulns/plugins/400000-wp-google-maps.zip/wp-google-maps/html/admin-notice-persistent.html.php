<div class="wpgmza-notice wpgmza-persistent-notice notice notice-success is-dismissible" style="margin-left:0; margin-right: 0">
	<h2 style="margin-top:5px"></h2>
	<p data-name="message"></p>
	<br>
	<a href="" data-link></a>
	<a href="" data-ajax></a>
</div>
<br>