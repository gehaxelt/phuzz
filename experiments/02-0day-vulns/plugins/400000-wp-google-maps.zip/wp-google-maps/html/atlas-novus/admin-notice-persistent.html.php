<div class="wpgmza-card wpgmza-notice wpgmza-persistent-notice wpgmza-shadow-high wpgmza-margin-b-20 notice is-dismissible">
	<h2></h2>
	<p data-name="message"></p>
	<a class='wpgmza-button' href="" data-link></a>
	<a class='wpgmza-button' href="" data-ajax></a>
</div>