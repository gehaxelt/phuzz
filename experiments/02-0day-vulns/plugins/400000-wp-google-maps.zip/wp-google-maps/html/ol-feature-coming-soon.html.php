<?php

if(!defined('ABSPATH'))
	return;

?><div class="notice notice-warning wpgmza-open-layers-feature-coming-soon" style="display: none;">
	<p>
		<?php
		_e('<strong>Coming soon</strong> to OpenLayers. If you need to use this feature, please go to settings then select and configure Google Maps to enable it.', 'wp-google-maps');
		?>
	</p>
</div>