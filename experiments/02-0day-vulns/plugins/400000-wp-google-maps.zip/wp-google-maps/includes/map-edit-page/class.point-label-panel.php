<?php

namespace WPGMZA;

class PointlabelPanel extends FeaturePanel {
	public function __construct($map_id){
		FeaturePanel::__construct($map_id);
	}
}