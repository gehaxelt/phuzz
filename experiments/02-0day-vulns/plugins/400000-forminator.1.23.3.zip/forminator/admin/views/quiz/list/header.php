<?php
$title         = __( 'Quizzes', 'forminator' );
$create_dialog = 'quizzes';
$import_dialog = 'import_quiz';
$hash          = '#quizzes';

require_once forminator_plugin_dir() . 'admin/views/common/list/header.php';
