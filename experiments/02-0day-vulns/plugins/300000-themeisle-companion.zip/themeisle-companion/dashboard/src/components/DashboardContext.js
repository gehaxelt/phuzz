import { createContext } from '@wordpress/element';

export const ModulesContext = createContext();
export const PluginsContext = createContext();
export const DashboardContext = createContext();
