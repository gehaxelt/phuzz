import StarterSitesUnavailable from './StarterSitesUnavailable';

const App = () => {
	return (
		<div>
			<StarterSitesUnavailable />
		</div>
	);
};

export default App;
