<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: src/views/SetupBlockOptions-Lite.vue:1192
	__( 'Blocks', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1193
	__( 'Sections', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1194
	__( 'Standard', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1195
	__( 'Advanced', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1196
	__( 'Saved Blocks', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1197
	__( 'Editing:', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1198
	__( 'Search blocks...', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1199
	__( 'WooCommerce', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1200
	__( 'Widgets', 'coming-soon' )
);
/* THIS IS THE END OF THE GENERATED FILE */
