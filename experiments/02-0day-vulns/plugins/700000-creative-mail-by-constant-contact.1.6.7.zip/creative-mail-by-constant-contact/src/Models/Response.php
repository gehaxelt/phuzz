<?php

namespace CreativeMail\Models;

class Response {

	/**
	 * Response URL string
	 *
	 * @var string
	 */
	public $url;
}
