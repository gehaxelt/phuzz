<?php


namespace CreativeMail\Modules\Contacts\Models;

class OptActionBy {
	const VISITOR = 1;
	const OWNER   = 2;
}
