<?php

namespace CreativeMail\Modules\Contacts\Models;

class FormidableContactForm {
	public string $firstName;
	public string $lastName;
	public string $birthday;
	public string $phone;
	public string $email;
	public string $isSync;
}
