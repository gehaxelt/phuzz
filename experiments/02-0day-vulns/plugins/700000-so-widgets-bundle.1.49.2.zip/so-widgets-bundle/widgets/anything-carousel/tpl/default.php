<?php

if ( ! empty( $settings['items'] ) ) {
	$this->render_template( $settings, $args );
}
