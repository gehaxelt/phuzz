<?php
/**
 * @var $controls array
 * @var $frames array
 */

$this->render_template( $controls, $frames );
