<?php

return array(
	'ABeeZee' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Abel' =>
		array(
			0 => 'regular',
		),
	'Abhaya Libre' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Aboreto' =>
		array(
			0 => 'regular',
		),
	'Abril Fatface' =>
		array(
			0 => 'regular',
		),
	'Aclonica' =>
		array(
			0 => 'regular',
		),
	'Acme' =>
		array(
			0 => 'regular',
		),
	'Actor' =>
		array(
			0 => 'regular',
		),
	'Adamina' =>
		array(
			0 => 'regular',
		),
	'Advent Pro' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'Aguafina Script' =>
		array(
			0 => 'regular',
		),
	'Akaya Kanadaka' =>
		array(
			0 => 'regular',
		),
	'Akaya Telivigala' =>
		array(
			0 => 'regular',
		),
	'Akronim' =>
		array(
			0 => 'regular',
		),
	'Akshar' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Aladin' =>
		array(
			0 => 'regular',
		),
	'Alata' =>
		array(
			0 => 'regular',
		),
	'Alatsi' =>
		array(
			0 => 'regular',
		),
	'Albert Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Aldrich' =>
		array(
			0 => 'regular',
		),
	'Alef' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Alegreya' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Alegreya SC' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '700',
			5 => '700italic',
			6 => '800',
			7 => '800italic',
			8 => '900',
			9 => '900italic',
		),
	'Alegreya Sans' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
	'Alegreya Sans SC' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
	'Aleo' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Alex Brush' =>
		array(
			0 => 'regular',
		),
	'Alfa Slab One' =>
		array(
			0 => 'regular',
		),
	'Alice' =>
		array(
			0 => 'regular',
		),
	'Alike' =>
		array(
			0 => 'regular',
		),
	'Alike Angular' =>
		array(
			0 => 'regular',
		),
	'Allan' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Allerta' =>
		array(
			0 => 'regular',
		),
	'Allerta Stencil' =>
		array(
			0 => 'regular',
		),
	'Allison' =>
		array(
			0 => 'regular',
		),
	'Allura' =>
		array(
			0 => 'regular',
		),
	'Almarai' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
			3 => '800',
		),
	'Almendra' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Almendra Display' =>
		array(
			0 => 'regular',
		),
	'Almendra SC' =>
		array(
			0 => 'regular',
		),
	'Alumni Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Alumni Sans Collegiate One' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Alumni Sans Inline One' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Alumni Sans Pinstripe' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Amarante' =>
		array(
			0 => 'regular',
		),
	'Amaranth' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Amatic SC' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Amethysta' =>
		array(
			0 => 'regular',
		),
	'Amiko' =>
		array(
			0 => 'regular',
			1 => '600',
			2 => '700',
		),
	'Amiri' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Amiri Quran' =>
		array(
			0 => 'regular',
		),
	'Amita' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Anaheim' =>
		array(
			0 => 'regular',
		),
	'Andada Pro' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => 'italic',
			6 => '500italic',
			7 => '600italic',
			8 => '700italic',
			9 => '800italic',
		),
	'Andika' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Anek Bangla' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Devanagari' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Gujarati' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Gurmukhi' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Kannada' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Latin' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Malayalam' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Odia' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Tamil' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Anek Telugu' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Angkor' =>
		array(
			0 => 'regular',
		),
	'Annie Use Your Telescope' =>
		array(
			0 => 'regular',
		),
	'Anonymous Pro' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Antic' =>
		array(
			0 => 'regular',
		),
	'Antic Didone' =>
		array(
			0 => 'regular',
		),
	'Antic Slab' =>
		array(
			0 => 'regular',
		),
	'Anton' =>
		array(
			0 => 'regular',
		),
	'Antonio' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'Anybody' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Arapey' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Arbutus' =>
		array(
			0 => 'regular',
		),
	'Arbutus Slab' =>
		array(
			0 => 'regular',
		),
	'Architects Daughter' =>
		array(
			0 => 'regular',
		),
	'Archivo' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Archivo Black' =>
		array(
			0 => 'regular',
		),
	'Archivo Narrow' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Are You Serious' =>
		array(
			0 => 'regular',
		),
	'Aref Ruqaa' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Aref Ruqaa Ink' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Arima' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'Arima Madurai' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Arimo' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Arizonia' =>
		array(
			0 => 'regular',
		),
	'Armata' =>
		array(
			0 => 'regular',
		),
	'Arsenal' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Artifika' =>
		array(
			0 => 'regular',
		),
	'Arvo' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Arya' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Asap' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Asap Condensed' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
		),
	'Asar' =>
		array(
			0 => 'regular',
		),
	'Asset' =>
		array(
			0 => 'regular',
		),
	'Assistant' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Astloch' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Asul' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Athiti' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Atkinson Hyperlegible' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Atma' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Atomic Age' =>
		array(
			0 => 'regular',
		),
	'Aubrey' =>
		array(
			0 => 'regular',
		),
	'Audiowide' =>
		array(
			0 => 'regular',
		),
	'Autour One' =>
		array(
			0 => 'regular',
		),
	'Average' =>
		array(
			0 => 'regular',
		),
	'Average Sans' =>
		array(
			0 => 'regular',
		),
	'Averia Gruesa Libre' =>
		array(
			0 => 'regular',
		),
	'Averia Libre' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Averia Sans Libre' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Averia Serif Libre' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Azeret Mono' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'B612' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'B612 Mono' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'BIZ UDGothic' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'BIZ UDMincho' =>
		array(
			0 => 'regular',
		),
	'BIZ UDPGothic' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'BIZ UDPMincho' =>
		array(
			0 => 'regular',
		),
	'Babylonica' =>
		array(
			0 => 'regular',
		),
	'Bad Script' =>
		array(
			0 => 'regular',
		),
	'Bahiana' =>
		array(
			0 => 'regular',
		),
	'Bahianita' =>
		array(
			0 => 'regular',
		),
	'Bai Jamjuree' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Bakbak One' =>
		array(
			0 => 'regular',
		),
	'Ballet' =>
		array(
			0 => 'regular',
		),
	'Baloo 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Bhai 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Bhaijaan 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Bhaina 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Chettan 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Da 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Paaji 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Tamma 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Tammudu 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Baloo Thambi 2' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Balsamiq Sans' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Balthazar' =>
		array(
			0 => 'regular',
		),
	'Bangers' =>
		array(
			0 => 'regular',
		),
	'Barlow' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Barlow Condensed' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Barlow Semi Condensed' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Barriecito' =>
		array(
			0 => 'regular',
		),
	'Barrio' =>
		array(
			0 => 'regular',
		),
	'Basic' =>
		array(
			0 => 'regular',
		),
	'Baskervville' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Battambang' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'Baumans' =>
		array(
			0 => 'regular',
		),
	'Bayon' =>
		array(
			0 => 'regular',
		),
	'Be Vietnam Pro' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Beau Rivage' =>
		array(
			0 => 'regular',
		),
	'Bebas Neue' =>
		array(
			0 => 'regular',
		),
	'Belgrano' =>
		array(
			0 => 'regular',
		),
	'Bellefair' =>
		array(
			0 => 'regular',
		),
	'Belleza' =>
		array(
			0 => 'regular',
		),
	'Bellota' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Bellota Text' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'BenchNine' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Benne' =>
		array(
			0 => 'regular',
		),
	'Bentham' =>
		array(
			0 => 'regular',
		),
	'Berkshire Swash' =>
		array(
			0 => 'regular',
		),
	'Besley' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Beth Ellen' =>
		array(
			0 => 'regular',
		),
	'Bevan' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'BhuTuka Expanded One' =>
		array(
			0 => 'regular',
		),
	'Big Shoulders Display' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Big Shoulders Inline Display' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Big Shoulders Inline Text' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Big Shoulders Stencil Display' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Big Shoulders Stencil Text' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Big Shoulders Text' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Bigelow Rules' =>
		array(
			0 => 'regular',
		),
	'Bigshot One' =>
		array(
			0 => 'regular',
		),
	'Bilbo' =>
		array(
			0 => 'regular',
		),
	'Bilbo Swash Caps' =>
		array(
			0 => 'regular',
		),
	'BioRhyme' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
	'BioRhyme Expanded' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
	'Birthstone' =>
		array(
			0 => 'regular',
		),
	'Birthstone Bounce' =>
		array(
			0 => 'regular',
			1 => '500',
		),
	'Biryani' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Bitter' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Black And White Picture' =>
		array(
			0 => 'regular',
		),
	'Black Han Sans' =>
		array(
			0 => 'regular',
		),
	'Black Ops One' =>
		array(
			0 => 'regular',
		),
	'Blaka' =>
		array(
			0 => 'regular',
		),
	'Blaka Hollow' =>
		array(
			0 => 'regular',
		),
	'Blaka Ink' =>
		array(
			0 => 'regular',
		),
	'Blinker' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Bodoni Moda' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Bokor' =>
		array(
			0 => 'regular',
		),
	'Bona Nova' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Bonbon' =>
		array(
			0 => 'regular',
		),
	'Bonheur Royale' =>
		array(
			0 => 'regular',
		),
	'Boogaloo' =>
		array(
			0 => 'regular',
		),
	'Bowlby One' =>
		array(
			0 => 'regular',
		),
	'Bowlby One SC' =>
		array(
			0 => 'regular',
		),
	'Brawler' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Bree Serif' =>
		array(
			0 => 'regular',
		),
	'Brygada 1918' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Bubblegum Sans' =>
		array(
			0 => 'regular',
		),
	'Bubbler One' =>
		array(
			0 => 'regular',
		),
	'Buda' =>
		array(
			0 => '300',
		),
	'Buenard' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Bungee' =>
		array(
			0 => 'regular',
		),
	'Bungee Hairline' =>
		array(
			0 => 'regular',
		),
	'Bungee Inline' =>
		array(
			0 => 'regular',
		),
	'Bungee Outline' =>
		array(
			0 => 'regular',
		),
	'Bungee Shade' =>
		array(
			0 => 'regular',
		),
	'Bungee Spice' =>
		array(
			0 => 'regular',
		),
	'Butcherman' =>
		array(
			0 => 'regular',
		),
	'Butterfly Kids' =>
		array(
			0 => 'regular',
		),
	'Cabin' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Cabin Condensed' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Cabin Sketch' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Caesar Dressing' =>
		array(
			0 => 'regular',
		),
	'Cagliostro' =>
		array(
			0 => 'regular',
		),
	'Cairo' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Cairo Play' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Caladea' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Calistoga' =>
		array(
			0 => 'regular',
		),
	'Calligraffitti' =>
		array(
			0 => 'regular',
		),
	'Cambay' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Cambo' =>
		array(
			0 => 'regular',
		),
	'Candal' =>
		array(
			0 => 'regular',
		),
	'Cantarell' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Cantata One' =>
		array(
			0 => 'regular',
		),
	'Cantora One' =>
		array(
			0 => 'regular',
		),
	'Capriola' =>
		array(
			0 => 'regular',
		),
	'Caramel' =>
		array(
			0 => 'regular',
		),
	'Carattere' =>
		array(
			0 => 'regular',
		),
	'Cardo' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Carme' =>
		array(
			0 => 'regular',
		),
	'Carrois Gothic' =>
		array(
			0 => 'regular',
		),
	'Carrois Gothic SC' =>
		array(
			0 => 'regular',
		),
	'Carter One' =>
		array(
			0 => 'regular',
		),
	'Castoro' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Catamaran' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Caudex' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Caveat' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Caveat Brush' =>
		array(
			0 => 'regular',
		),
	'Cedarville Cursive' =>
		array(
			0 => 'regular',
		),
	'Ceviche One' =>
		array(
			0 => 'regular',
		),
	'Chakra Petch' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
	'Changa' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Changa One' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Chango' =>
		array(
			0 => 'regular',
		),
	'Charis SIL' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Charm' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Charmonman' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Chathura' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
	'Chau Philomene One' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Chela One' =>
		array(
			0 => 'regular',
		),
	'Chelsea Market' =>
		array(
			0 => 'regular',
		),
	'Chenla' =>
		array(
			0 => 'regular',
		),
	'Cherish' =>
		array(
			0 => 'regular',
		),
	'Cherry Cream Soda' =>
		array(
			0 => 'regular',
		),
	'Cherry Swash' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Chewy' =>
		array(
			0 => 'regular',
		),
	'Chicle' =>
		array(
			0 => 'regular',
		),
	'Chilanka' =>
		array(
			0 => 'regular',
		),
	'Chivo' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
			6 => '900',
			7 => '900italic',
		),
	'Chonburi' =>
		array(
			0 => 'regular',
		),
	'Cinzel' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
	'Cinzel Decorative' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Clicker Script' =>
		array(
			0 => 'regular',
		),
	'Coda' =>
		array(
			0 => 'regular',
			1 => '800',
		),
	'Coda Caption' =>
		array(
			0 => '800',
		),
	'Codystar' =>
		array(
			0 => '300',
			1 => 'regular',
		),
	'Coiny' =>
		array(
			0 => 'regular',
		),
	'Combo' =>
		array(
			0 => 'regular',
		),
	'Comfortaa' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Comforter' =>
		array(
			0 => 'regular',
		),
	'Comforter Brush' =>
		array(
			0 => 'regular',
		),
	'Comic Neue' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Coming Soon' =>
		array(
			0 => 'regular',
		),
	'Commissioner' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Concert One' =>
		array(
			0 => 'regular',
		),
	'Condiment' =>
		array(
			0 => 'regular',
		),
	'Content' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Contrail One' =>
		array(
			0 => 'regular',
		),
	'Convergence' =>
		array(
			0 => 'regular',
		),
	'Cookie' =>
		array(
			0 => 'regular',
		),
	'Copse' =>
		array(
			0 => 'regular',
		),
	'Corben' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Corinthia' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Cormorant' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Cormorant Garamond' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
	'Cormorant Infant' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
	'Cormorant SC' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Cormorant Unicase' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Cormorant Upright' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Courgette' =>
		array(
			0 => 'regular',
		),
	'Courier Prime' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Cousine' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Coustard' =>
		array(
			0 => 'regular',
			1 => '900',
		),
	'Covered By Your Grace' =>
		array(
			0 => 'regular',
		),
	'Crafty Girls' =>
		array(
			0 => 'regular',
		),
	'Creepster' =>
		array(
			0 => 'regular',
		),
	'Crete Round' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Crimson Pro' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Crimson Text' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '600',
			3 => '600italic',
			4 => '700',
			5 => '700italic',
		),
	'Croissant One' =>
		array(
			0 => 'regular',
		),
	'Crushed' =>
		array(
			0 => 'regular',
		),
	'Cuprum' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Cute Font' =>
		array(
			0 => 'regular',
		),
	'Cutive' =>
		array(
			0 => 'regular',
		),
	'Cutive Mono' =>
		array(
			0 => 'regular',
		),
	'DM Mono' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
		),
	'DM Sans' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '700',
			5 => '700italic',
		),
	'DM Serif Display' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'DM Serif Text' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Damion' =>
		array(
			0 => 'regular',
		),
	'Dancing Script' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Dangrek' =>
		array(
			0 => 'regular',
		),
	'Darker Grotesque' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'David Libre' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Dawning of a New Day' =>
		array(
			0 => 'regular',
		),
	'Days One' =>
		array(
			0 => 'regular',
		),
	'Dekko' =>
		array(
			0 => 'regular',
		),
	'Dela Gothic One' =>
		array(
			0 => 'regular',
		),
	'Delius' =>
		array(
			0 => 'regular',
		),
	'Delius Swash Caps' =>
		array(
			0 => 'regular',
		),
	'Delius Unicase' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Della Respira' =>
		array(
			0 => 'regular',
		),
	'Denk One' =>
		array(
			0 => 'regular',
		),
	'Devonshire' =>
		array(
			0 => 'regular',
		),
	'Dhurjati' =>
		array(
			0 => 'regular',
		),
	'Didact Gothic' =>
		array(
			0 => 'regular',
		),
	'Diplomata' =>
		array(
			0 => 'regular',
		),
	'Diplomata SC' =>
		array(
			0 => 'regular',
		),
	'Do Hyeon' =>
		array(
			0 => 'regular',
		),
	'Dokdo' =>
		array(
			0 => 'regular',
		),
	'Domine' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Donegal One' =>
		array(
			0 => 'regular',
		),
	'Dongle' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Doppio One' =>
		array(
			0 => 'regular',
		),
	'Dorsa' =>
		array(
			0 => 'regular',
		),
	'Dosis' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'DotGothic16' =>
		array(
			0 => 'regular',
		),
	'Dr Sugiyama' =>
		array(
			0 => 'regular',
		),
	'Duru Sans' =>
		array(
			0 => 'regular',
		),
	'DynaPuff' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Dynalight' =>
		array(
			0 => 'regular',
		),
	'EB Garamond' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => 'italic',
			6 => '500italic',
			7 => '600italic',
			8 => '700italic',
			9 => '800italic',
		),
	'Eagle Lake' =>
		array(
			0 => 'regular',
		),
	'East Sea Dokdo' =>
		array(
			0 => 'regular',
		),
	'Eater' =>
		array(
			0 => 'regular',
		),
	'Economica' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Eczar' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Edu NSW ACT Foundation' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Edu QLD Beginner' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Edu SA Beginner' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Edu TAS Beginner' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Edu VIC WA NT Beginner' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'El Messiri' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Electrolize' =>
		array(
			0 => 'regular',
		),
	'Elsie' =>
		array(
			0 => 'regular',
			1 => '900',
		),
	'Elsie Swash Caps' =>
		array(
			0 => 'regular',
			1 => '900',
		),
	'Emblema One' =>
		array(
			0 => 'regular',
		),
	'Emilys Candy' =>
		array(
			0 => 'regular',
		),
	'Encode Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Encode Sans Condensed' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Encode Sans Expanded' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Encode Sans SC' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Encode Sans Semi Condensed' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Encode Sans Semi Expanded' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Engagement' =>
		array(
			0 => 'regular',
		),
	'Englebert' =>
		array(
			0 => 'regular',
		),
	'Enriqueta' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Ephesis' =>
		array(
			0 => 'regular',
		),
	'Epilogue' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Erica One' =>
		array(
			0 => 'regular',
		),
	'Esteban' =>
		array(
			0 => 'regular',
		),
	'Estonia' =>
		array(
			0 => 'regular',
		),
	'Euphoria Script' =>
		array(
			0 => 'regular',
		),
	'Ewert' =>
		array(
			0 => 'regular',
		),
	'Exo' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Exo 2' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Expletus Sans' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Explora' =>
		array(
			0 => 'regular',
		),
	'Fahkwang' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Familjen Grotesk' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Fanwood Text' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Farro' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
		),
	'Farsan' =>
		array(
			0 => 'regular',
		),
	'Fascinate' =>
		array(
			0 => 'regular',
		),
	'Fascinate Inline' =>
		array(
			0 => 'regular',
		),
	'Faster One' =>
		array(
			0 => 'regular',
		),
	'Fasthand' =>
		array(
			0 => 'regular',
		),
	'Fauna One' =>
		array(
			0 => 'regular',
		),
	'Faustina' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '300italic',
			7 => 'italic',
			8 => '500italic',
			9 => '600italic',
			10 => '700italic',
			11 => '800italic',
		),
	'Federant' =>
		array(
			0 => 'regular',
		),
	'Federo' =>
		array(
			0 => 'regular',
		),
	'Felipa' =>
		array(
			0 => 'regular',
		),
	'Fenix' =>
		array(
			0 => 'regular',
		),
	'Festive' =>
		array(
			0 => 'regular',
		),
	'Figtree' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Finger Paint' =>
		array(
			0 => 'regular',
		),
	'Finlandica' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Fira Code' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Fira Mono' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Fira Sans' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Fira Sans Condensed' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Fira Sans Extra Condensed' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Fjalla One' =>
		array(
			0 => 'regular',
		),
	'Fjord One' =>
		array(
			0 => 'regular',
		),
	'Flamenco' =>
		array(
			0 => '300',
			1 => 'regular',
		),
	'Flavors' =>
		array(
			0 => 'regular',
		),
	'Fleur De Leah' =>
		array(
			0 => 'regular',
		),
	'Flow Block' =>
		array(
			0 => 'regular',
		),
	'Flow Circular' =>
		array(
			0 => 'regular',
		),
	'Flow Rounded' =>
		array(
			0 => 'regular',
		),
	'Fondamento' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Fontdiner Swanky' =>
		array(
			0 => 'regular',
		),
	'Forum' =>
		array(
			0 => 'regular',
		),
	'Francois One' =>
		array(
			0 => 'regular',
		),
	'Frank Ruhl Libre' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '900',
		),
	'Fraunces' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Freckle Face' =>
		array(
			0 => 'regular',
		),
	'Fredericka the Great' =>
		array(
			0 => 'regular',
		),
	'Fredoka' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Fredoka One' =>
		array(
			0 => 'regular',
		),
	'Freehand' =>
		array(
			0 => 'regular',
		),
	'Fresca' =>
		array(
			0 => 'regular',
		),
	'Frijole' =>
		array(
			0 => 'regular',
		),
	'Fruktur' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Fugaz One' =>
		array(
			0 => 'regular',
		),
	'Fuggles' =>
		array(
			0 => 'regular',
		),
	'Fuzzy Bubbles' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'GFS Didot' =>
		array(
			0 => 'regular',
		),
	'GFS Neohellenic' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Gabriela' =>
		array(
			0 => 'regular',
		),
	'Gaegu' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Gafata' =>
		array(
			0 => 'regular',
		),
	'Galada' =>
		array(
			0 => 'regular',
		),
	'Galdeano' =>
		array(
			0 => 'regular',
		),
	'Galindo' =>
		array(
			0 => 'regular',
		),
	'Gamja Flower' =>
		array(
			0 => 'regular',
		),
	'Gantari' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Gayathri' =>
		array(
			0 => '100',
			1 => 'regular',
			2 => '700',
		),
	'Gelasio' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
		),
	'Gemunu Libre' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Genos' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Gentium Book Basic' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Gentium Book Plus' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Gentium Plus' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Geo' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Georama' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Geostar' =>
		array(
			0 => 'regular',
		),
	'Geostar Fill' =>
		array(
			0 => 'regular',
		),
	'Germania One' =>
		array(
			0 => 'regular',
		),
	'Gideon Roman' =>
		array(
			0 => 'regular',
		),
	'Gidugu' =>
		array(
			0 => 'regular',
		),
	'Gilda Display' =>
		array(
			0 => 'regular',
		),
	'Girassol' =>
		array(
			0 => 'regular',
		),
	'Give You Glory' =>
		array(
			0 => 'regular',
		),
	'Glass Antiqua' =>
		array(
			0 => 'regular',
		),
	'Glegoo' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Gloria Hallelujah' =>
		array(
			0 => 'regular',
		),
	'Glory' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '100italic',
			9 => '200italic',
			10 => '300italic',
			11 => 'italic',
			12 => '500italic',
			13 => '600italic',
			14 => '700italic',
			15 => '800italic',
		),
	'Gluten' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Goblin One' =>
		array(
			0 => 'regular',
		),
	'Gochi Hand' =>
		array(
			0 => 'regular',
		),
	'Goldman' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Gorditas' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Gothic A1' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Gotu' =>
		array(
			0 => 'regular',
		),
	'Goudy Bookletter 1911' =>
		array(
			0 => 'regular',
		),
	'Gowun Batang' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Gowun Dodum' =>
		array(
			0 => 'regular',
		),
	'Graduate' =>
		array(
			0 => 'regular',
		),
	'Grand Hotel' =>
		array(
			0 => 'regular',
		),
	'Grandstander' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Grape Nuts' =>
		array(
			0 => 'regular',
		),
	'Gravitas One' =>
		array(
			0 => 'regular',
		),
	'Great Vibes' =>
		array(
			0 => 'regular',
		),
	'Grechen Fuemen' =>
		array(
			0 => 'regular',
		),
	'Grenze' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Grenze Gotisch' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Grey Qo' =>
		array(
			0 => 'regular',
		),
	'Griffy' =>
		array(
			0 => 'regular',
		),
	'Gruppo' =>
		array(
			0 => 'regular',
		),
	'Gudea' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Gugi' =>
		array(
			0 => 'regular',
		),
	'Gulzar' =>
		array(
			0 => 'regular',
		),
	'Gupter' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Gurajada' =>
		array(
			0 => 'regular',
		),
	'Gwendolyn' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Habibi' =>
		array(
			0 => 'regular',
		),
	'Hachi Maru Pop' =>
		array(
			0 => 'regular',
		),
	'Hahmlet' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Halant' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Hammersmith One' =>
		array(
			0 => 'regular',
		),
	'Hanalei' =>
		array(
			0 => 'regular',
		),
	'Hanalei Fill' =>
		array(
			0 => 'regular',
		),
	'Handlee' =>
		array(
			0 => 'regular',
		),
	'Hanuman' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'Happy Monkey' =>
		array(
			0 => 'regular',
		),
	'Harmattan' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Headland One' =>
		array(
			0 => 'regular',
		),
	'Heebo' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Henny Penny' =>
		array(
			0 => 'regular',
		),
	'Hepta Slab' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Herr Von Muellerhoff' =>
		array(
			0 => 'regular',
		),
	'Hi Melody' =>
		array(
			0 => 'regular',
		),
	'Hina Mincho' =>
		array(
			0 => 'regular',
		),
	'Hind' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Hind Guntur' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Hind Madurai' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Hind Siliguri' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Hind Vadodara' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Holtwood One SC' =>
		array(
			0 => 'regular',
		),
	'Homemade Apple' =>
		array(
			0 => 'regular',
		),
	'Homenaje' =>
		array(
			0 => 'regular',
		),
	'Hubballi' =>
		array(
			0 => 'regular',
		),
	'Hurricane' =>
		array(
			0 => 'regular',
		),
	'IBM Plex Mono' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
		),
	'IBM Plex Sans' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
		),
	'IBM Plex Sans Arabic' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Sans Condensed' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
		),
	'IBM Plex Sans Devanagari' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Sans Hebrew' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Sans KR' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Sans Thai' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Sans Thai Looped' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'IBM Plex Serif' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
		),
	'IM Fell DW Pica' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'IM Fell DW Pica SC' =>
		array(
			0 => 'regular',
		),
	'IM Fell Double Pica' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'IM Fell Double Pica SC' =>
		array(
			0 => 'regular',
		),
	'IM Fell English' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'IM Fell English SC' =>
		array(
			0 => 'regular',
		),
	'IM Fell French Canon' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'IM Fell French Canon SC' =>
		array(
			0 => 'regular',
		),
	'IM Fell Great Primer' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'IM Fell Great Primer SC' =>
		array(
			0 => 'regular',
		),
	'Ibarra Real Nova' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Iceberg' =>
		array(
			0 => 'regular',
		),
	'Iceland' =>
		array(
			0 => 'regular',
		),
	'Imbue' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Imperial Script' =>
		array(
			0 => 'regular',
		),
	'Imprima' =>
		array(
			0 => 'regular',
		),
	'Inconsolata' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Inder' =>
		array(
			0 => 'regular',
		),
	'Indie Flower' =>
		array(
			0 => 'regular',
		),
	'Ingrid Darling' =>
		array(
			0 => 'regular',
		),
	'Inika' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Inknut Antiqua' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Inria Sans' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Inria Serif' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Inspiration' =>
		array(
			0 => 'regular',
		),
	'Inter' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Irish Grover' =>
		array(
			0 => 'regular',
		),
	'Island Moments' =>
		array(
			0 => 'regular',
		),
	'Istok Web' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Italiana' =>
		array(
			0 => 'regular',
		),
	'Italianno' =>
		array(
			0 => 'regular',
		),
	'Itim' =>
		array(
			0 => 'regular',
		),
	'Jacques Francois' =>
		array(
			0 => 'regular',
		),
	'Jacques Francois Shadow' =>
		array(
			0 => 'regular',
		),
	'Jaldi' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'JetBrains Mono' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '100italic',
			9 => '200italic',
			10 => '300italic',
			11 => 'italic',
			12 => '500italic',
			13 => '600italic',
			14 => '700italic',
			15 => '800italic',
		),
	'Jim Nightshade' =>
		array(
			0 => 'regular',
		),
	'Joan' =>
		array(
			0 => 'regular',
		),
	'Jockey One' =>
		array(
			0 => 'regular',
		),
	'Jolly Lodger' =>
		array(
			0 => 'regular',
		),
	'Jomhuria' =>
		array(
			0 => 'regular',
		),
	'Jomolhari' =>
		array(
			0 => 'regular',
		),
	'Josefin Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '100italic',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
		),
	'Josefin Slab' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '100italic',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
		),
	'Jost' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Joti One' =>
		array(
			0 => 'regular',
		),
	'Jua' =>
		array(
			0 => 'regular',
		),
	'Judson' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Julee' =>
		array(
			0 => 'regular',
		),
	'Julius Sans One' =>
		array(
			0 => 'regular',
		),
	'Junge' =>
		array(
			0 => 'regular',
		),
	'Jura' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Just Another Hand' =>
		array(
			0 => 'regular',
		),
	'Just Me Again Down Here' =>
		array(
			0 => 'regular',
		),
	'K2D' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
		),
	'Kadwa' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Kaisei Decol' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Kaisei HarunoUmi' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Kaisei Opti' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
	'Kaisei Tokumin' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '800',
		),
	'Kalam' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Kameron' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Kanit' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Kantumruy' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Kantumruy Pro' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '100italic',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
		),
	'Karantina' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Karla' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '200italic',
			8 => '300italic',
			9 => 'italic',
			10 => '500italic',
			11 => '600italic',
			12 => '700italic',
			13 => '800italic',
		),
	'Karma' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Katibeh' =>
		array(
			0 => 'regular',
		),
	'Kaushan Script' =>
		array(
			0 => 'regular',
		),
	'Kavivanar' =>
		array(
			0 => 'regular',
		),
	'Kavoon' =>
		array(
			0 => 'regular',
		),
	'Kdam Thmor Pro' =>
		array(
			0 => 'regular',
		),
	'Keania One' =>
		array(
			0 => 'regular',
		),
	'Kelly Slab' =>
		array(
			0 => 'regular',
		),
	'Kenia' =>
		array(
			0 => 'regular',
		),
	'Khand' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Khmer' =>
		array(
			0 => 'regular',
		),
	'Khula' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Kings' =>
		array(
			0 => 'regular',
		),
	'Kirang Haerang' =>
		array(
			0 => 'regular',
		),
	'Kite One' =>
		array(
			0 => 'regular',
		),
	'Kiwi Maru' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
		),
	'Klee One' =>
		array(
			0 => 'regular',
			1 => '600',
		),
	'Knewave' =>
		array(
			0 => 'regular',
		),
	'KoHo' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Kodchasan' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Koh Santepheap' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'Kolker Brush' =>
		array(
			0 => 'regular',
		),
	'Kosugi' =>
		array(
			0 => 'regular',
		),
	'Kosugi Maru' =>
		array(
			0 => 'regular',
		),
	'Kotta One' =>
		array(
			0 => 'regular',
		),
	'Koulen' =>
		array(
			0 => 'regular',
		),
	'Kranky' =>
		array(
			0 => 'regular',
		),
	'Kreon' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Kristi' =>
		array(
			0 => 'regular',
		),
	'Krona One' =>
		array(
			0 => 'regular',
		),
	'Krub' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Kufam' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Kulim Park' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
	'Kumar One' =>
		array(
			0 => 'regular',
		),
	'Kumar One Outline' =>
		array(
			0 => 'regular',
		),
	'Kumbh Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Kurale' =>
		array(
			0 => 'regular',
		),
	'La Belle Aurore' =>
		array(
			0 => 'regular',
		),
	'Lacquer' =>
		array(
			0 => 'regular',
		),
	'Laila' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Lakki Reddy' =>
		array(
			0 => 'regular',
		),
	'Lalezar' =>
		array(
			0 => 'regular',
		),
	'Lancelot' =>
		array(
			0 => 'regular',
		),
	'Langar' =>
		array(
			0 => 'regular',
		),
	'Lateef' =>
		array(
			0 => 'regular',
		),
	'Lato' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '700',
			7 => '700italic',
			8 => '900',
			9 => '900italic',
		),
	'Lavishly Yours' =>
		array(
			0 => 'regular',
		),
	'League Gothic' =>
		array(
			0 => 'regular',
		),
	'League Script' =>
		array(
			0 => 'regular',
		),
	'League Spartan' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Leckerli One' =>
		array(
			0 => 'regular',
		),
	'Ledger' =>
		array(
			0 => 'regular',
		),
	'Lekton' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Lemon' =>
		array(
			0 => 'regular',
		),
	'Lemonada' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Lexend' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Deca' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Exa' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Giga' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Mega' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Peta' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Tera' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Lexend Zetta' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Libre Barcode 128' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode 128 Text' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode 39' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode 39 Extended' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode 39 Extended Text' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode 39 Text' =>
		array(
			0 => 'regular',
		),
	'Libre Barcode EAN13 Text' =>
		array(
			0 => 'regular',
		),
	'Libre Baskerville' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Libre Bodoni' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Libre Caslon Display' =>
		array(
			0 => 'regular',
		),
	'Libre Caslon Text' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Libre Franklin' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Licorice' =>
		array(
			0 => 'regular',
		),
	'Life Savers' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '800',
		),
	'Lilita One' =>
		array(
			0 => 'regular',
		),
	'Lily Script One' =>
		array(
			0 => 'regular',
		),
	'Limelight' =>
		array(
			0 => 'regular',
		),
	'Linden Hill' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Literata' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Liu Jian Mao Cao' =>
		array(
			0 => 'regular',
		),
	'Livvic' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '900',
			15 => '900italic',
		),
	'Lobster' =>
		array(
			0 => 'regular',
		),
	'Lobster Two' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Londrina Outline' =>
		array(
			0 => 'regular',
		),
	'Londrina Shadow' =>
		array(
			0 => 'regular',
		),
	'Londrina Sketch' =>
		array(
			0 => 'regular',
		),
	'Londrina Solid' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '900',
		),
	'Long Cang' =>
		array(
			0 => 'regular',
		),
	'Lora' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Love Light' =>
		array(
			0 => 'regular',
		),
	'Love Ya Like A Sister' =>
		array(
			0 => 'regular',
		),
	'Loved by the King' =>
		array(
			0 => 'regular',
		),
	'Lovers Quarrel' =>
		array(
			0 => 'regular',
		),
	'Luckiest Guy' =>
		array(
			0 => 'regular',
		),
	'Lusitana' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Lustria' =>
		array(
			0 => 'regular',
		),
	'Luxurious Roman' =>
		array(
			0 => 'regular',
		),
	'Luxurious Script' =>
		array(
			0 => 'regular',
		),
	'M PLUS 1' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'M PLUS 1 Code' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'M PLUS 1p' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'M PLUS 2' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'M PLUS Code Latin' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'M PLUS Rounded 1c' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Ma Shan Zheng' =>
		array(
			0 => 'regular',
		),
	'Macondo' =>
		array(
			0 => 'regular',
		),
	'Macondo Swash Caps' =>
		array(
			0 => 'regular',
		),
	'Mada' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Magra' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Maiden Orange' =>
		array(
			0 => 'regular',
		),
	'Maitree' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Major Mono Display' =>
		array(
			0 => 'regular',
		),
	'Mako' =>
		array(
			0 => 'regular',
		),
	'Mali' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Mallanna' =>
		array(
			0 => 'regular',
		),
	'Mandali' =>
		array(
			0 => 'regular',
		),
	'Manjari' =>
		array(
			0 => '100',
			1 => 'regular',
			2 => '700',
		),
	'Manrope' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Mansalva' =>
		array(
			0 => 'regular',
		),
	'Manuale' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '300italic',
			7 => 'italic',
			8 => '500italic',
			9 => '600italic',
			10 => '700italic',
			11 => '800italic',
		),
	'Marcellus' =>
		array(
			0 => 'regular',
		),
	'Marcellus SC' =>
		array(
			0 => 'regular',
		),
	'Marck Script' =>
		array(
			0 => 'regular',
		),
	'Margarine' =>
		array(
			0 => 'regular',
		),
	'Markazi Text' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Marko One' =>
		array(
			0 => 'regular',
		),
	'Marmelad' =>
		array(
			0 => 'regular',
		),
	'Martel' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Martel Sans' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Marvel' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Mate' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Mate SC' =>
		array(
			0 => 'regular',
		),
	'Maven Pro' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
	'McLaren' =>
		array(
			0 => 'regular',
		),
	'Mea Culpa' =>
		array(
			0 => 'regular',
		),
	'Meddon' =>
		array(
			0 => 'regular',
		),
	'MedievalSharp' =>
		array(
			0 => 'regular',
		),
	'Medula One' =>
		array(
			0 => 'regular',
		),
	'Meera Inimai' =>
		array(
			0 => 'regular',
		),
	'Megrim' =>
		array(
			0 => 'regular',
		),
	'Meie Script' =>
		array(
			0 => 'regular',
		),
	'Meow Script' =>
		array(
			0 => 'regular',
		),
	'Merienda' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Merienda One' =>
		array(
			0 => 'regular',
		),
	'Merriweather' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
			6 => '900',
			7 => '900italic',
		),
	'Merriweather Sans' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '300italic',
			7 => 'italic',
			8 => '500italic',
			9 => '600italic',
			10 => '700italic',
			11 => '800italic',
		),
	'Metal' =>
		array(
			0 => 'regular',
		),
	'Metal Mania' =>
		array(
			0 => 'regular',
		),
	'Metamorphous' =>
		array(
			0 => 'regular',
		),
	'Metrophobic' =>
		array(
			0 => 'regular',
		),
	'Michroma' =>
		array(
			0 => 'regular',
		),
	'Milonga' =>
		array(
			0 => 'regular',
		),
	'Miltonian' =>
		array(
			0 => 'regular',
		),
	'Miltonian Tattoo' =>
		array(
			0 => 'regular',
		),
	'Mina' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Mingzat' =>
		array(
			0 => 'regular',
		),
	'Miniver' =>
		array(
			0 => 'regular',
		),
	'Miriam Libre' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Mirza' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Miss Fajardose' =>
		array(
			0 => 'regular',
		),
	'Mitr' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Mochiy Pop One' =>
		array(
			0 => 'regular',
		),
	'Mochiy Pop P One' =>
		array(
			0 => 'regular',
		),
	'Modak' =>
		array(
			0 => 'regular',
		),
	'Modern Antiqua' =>
		array(
			0 => 'regular',
		),
	'Mogra' =>
		array(
			0 => 'regular',
		),
	'Mohave' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Molengo' =>
		array(
			0 => 'regular',
		),
	'Molle' =>
		array(
			0 => 'italic',
		),
	'Monda' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Monofett' =>
		array(
			0 => 'regular',
		),
	'Monoton' =>
		array(
			0 => 'regular',
		),
	'Monsieur La Doulaise' =>
		array(
			0 => 'regular',
		),
	'Montaga' =>
		array(
			0 => 'regular',
		),
	'Montagu Slab' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'MonteCarlo' =>
		array(
			0 => 'regular',
		),
	'Montez' =>
		array(
			0 => 'regular',
		),
	'Montserrat' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Montserrat Alternates' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Montserrat Subrayada' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Moo Lah Lah' =>
		array(
			0 => 'regular',
		),
	'Moon Dance' =>
		array(
			0 => 'regular',
		),
	'Moul' =>
		array(
			0 => 'regular',
		),
	'Moulpali' =>
		array(
			0 => 'regular',
		),
	'Mountains of Christmas' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Mouse Memoirs' =>
		array(
			0 => 'regular',
		),
	'Mr Bedfort' =>
		array(
			0 => 'regular',
		),
	'Mr Dafoe' =>
		array(
			0 => 'regular',
		),
	'Mr De Haviland' =>
		array(
			0 => 'regular',
		),
	'Mrs Saint Delafield' =>
		array(
			0 => 'regular',
		),
	'Mrs Sheppards' =>
		array(
			0 => 'regular',
		),
	'Ms Madi' =>
		array(
			0 => 'regular',
		),
	'Mukta' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Mukta Mahee' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Mukta Malar' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Mukta Vaani' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Mulish' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Murecho' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'MuseoModerno' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'My Soul' =>
		array(
			0 => 'regular',
		),
	'Mystery Quest' =>
		array(
			0 => 'regular',
		),
	'NTR' =>
		array(
			0 => 'regular',
		),
	'Nabla' =>
		array(
			0 => 'regular',
		),
	'Nanum Brush Script' =>
		array(
			0 => 'regular',
		),
	'Nanum Gothic' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '800',
		),
	'Nanum Gothic Coding' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Nanum Myeongjo' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '800',
		),
	'Nanum Pen Script' =>
		array(
			0 => 'regular',
		),
	'Neonderthaw' =>
		array(
			0 => 'regular',
		),
	'Nerko One' =>
		array(
			0 => 'regular',
		),
	'Neucha' =>
		array(
			0 => 'regular',
		),
	'Neuton' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '800',
		),
	'New Rocker' =>
		array(
			0 => 'regular',
		),
	'New Tegomin' =>
		array(
			0 => 'regular',
		),
	'News Cycle' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Newsreader' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '200italic',
			8 => '300italic',
			9 => 'italic',
			10 => '500italic',
			11 => '600italic',
			12 => '700italic',
			13 => '800italic',
		),
	'Niconne' =>
		array(
			0 => 'regular',
		),
	'Niramit' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
		),
	'Nixie One' =>
		array(
			0 => 'regular',
		),
	'Nobile' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '700',
			5 => '700italic',
		),
	'Nokora' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'Norican' =>
		array(
			0 => 'regular',
		),
	'Nosifer' =>
		array(
			0 => 'regular',
		),
	'Notable' =>
		array(
			0 => 'regular',
		),
	'Nothing You Could Do' =>
		array(
			0 => 'regular',
		),
	'Noticia Text' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Noto Color Emoji' =>
		array(
			0 => 'regular',
		),
	'Noto Emoji' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Noto Kufi Arabic' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Music' =>
		array(
			0 => 'regular',
		),
	'Noto Naskh Arabic' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Nastaliq Urdu' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Noto Rashi Hebrew' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Noto Sans Adlam' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Adlam Unjoined' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Anatolian Hieroglyphs' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Arabic' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Armenian' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Avestan' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Balinese' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Bamum' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Bassa Vah' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Batak' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Bengali' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Bhaiksuki' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Brahmi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Buginese' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Buhid' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Canadian Aboriginal' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Carian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Caucasian Albanian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Chakma' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Cham' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Cherokee' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Coptic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Cuneiform' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Cypriot' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Deseret' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Devanagari' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Display' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Noto Sans Duployan' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Egyptian Hieroglyphs' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Elbasan' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Elymaic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Georgian' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Glagolitic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Gothic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Grantha' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Gujarati' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Gunjala Gondi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Gurmukhi' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans HK' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Noto Sans Hanifi Rohingya' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Hanunoo' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Hatran' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Hebrew' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Imperial Aramaic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Indic Siyaq Numbers' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Inscriptional Pahlavi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Inscriptional Parthian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans JP' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Noto Sans Javanese' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Noto Sans KR' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Noto Sans Kaithi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Kannada' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Kayah Li' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Kharoshthi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Khmer' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Khojki' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Khudawadi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Lao' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Lepcha' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Limbu' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Linear A' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Linear B' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Lisu' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Lycian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Lydian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Mahajani' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Malayalam' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Mandaic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Manichaean' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Marchen' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Masaram Gondi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Math' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Mayan Numerals' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Medefaidrin' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Meetei Mayek' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Meroitic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Miao' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Modi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Mongolian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Mono' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Mro' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Multani' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Myanmar' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans N Ko' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Nabataean' =>
		array(
			0 => 'regular',
		),
	'Noto Sans New Tai Lue' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Newa' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Nushu' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Ogham' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Ol Chiki' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Old Hungarian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old Italic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old North Arabian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old Permic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old Persian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old Sogdian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old South Arabian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Old Turkic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Oriya' =>
		array(
			0 => '100',
			1 => 'regular',
			2 => '700',
			3 => '900',
		),
	'Noto Sans Osage' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Osmanya' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Pahawh Hmong' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Palmyrene' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Pau Cin Hau' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Phags Pa' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Phoenician' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Psalter Pahlavi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Rejang' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Runic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans SC' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Noto Sans Samaritan' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Saurashtra' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Sharada' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Shavian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Siddham' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Sinhala' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Sogdian' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Sora Sompeng' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Soyombo' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Sundanese' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Syloti Nagri' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Symbols' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Symbols 2' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Syriac' =>
		array(
			0 => '100',
			1 => 'regular',
			2 => '900',
		),
	'Noto Sans TC' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Noto Sans Tagalog' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Tagbanwa' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Tai Le' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Tai Tham' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Sans Tai Viet' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Takri' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Tamil' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Tamil Supplement' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Telugu' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Thaana' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Thai' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Thai Looped' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Sans Tifinagh' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Tirhuta' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Ugaritic' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Vai' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Wancho' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Warang Citi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Yi' =>
		array(
			0 => 'regular',
		),
	'Noto Sans Zanabazar Square' =>
		array(
			0 => 'regular',
		),
	'Noto Serif' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Noto Serif Ahom' =>
		array(
			0 => 'regular',
		),
	'Noto Serif Armenian' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Balinese' =>
		array(
			0 => 'regular',
		),
	'Noto Serif Bengali' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Devanagari' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Display' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Noto Serif Dogra' =>
		array(
			0 => 'regular',
		),
	'Noto Serif Ethiopic' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Georgian' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Grantha' =>
		array(
			0 => 'regular',
		),
	'Noto Serif Gujarati' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Gurmukhi' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif HK' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
		),
	'Noto Serif Hebrew' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif JP' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Noto Serif KR' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Noto Serif Kannada' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Khmer' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Lao' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Malayalam' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Myanmar' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Nyiakeng Puachue Hmong' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Serif SC' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Noto Serif Sinhala' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif TC' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Noto Serif Tamil' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Noto Serif Tangut' =>
		array(
			0 => 'regular',
		),
	'Noto Serif Telugu' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Thai' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Tibetan' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Noto Serif Yezidi' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Noto Traditional Nushu' =>
		array(
			0 => 'regular',
		),
	'Nova Cut' =>
		array(
			0 => 'regular',
		),
	'Nova Flat' =>
		array(
			0 => 'regular',
		),
	'Nova Mono' =>
		array(
			0 => 'regular',
		),
	'Nova Oval' =>
		array(
			0 => 'regular',
		),
	'Nova Round' =>
		array(
			0 => 'regular',
		),
	'Nova Script' =>
		array(
			0 => 'regular',
		),
	'Nova Slim' =>
		array(
			0 => 'regular',
		),
	'Nova Square' =>
		array(
			0 => 'regular',
		),
	'Numans' =>
		array(
			0 => 'regular',
		),
	'Nunito' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Nunito Sans' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
	'Nuosu SIL' =>
		array(
			0 => 'regular',
		),
	'Odibee Sans' =>
		array(
			0 => 'regular',
		),
	'Odor Mean Chey' =>
		array(
			0 => 'regular',
		),
	'Offside' =>
		array(
			0 => 'regular',
		),
	'Oi' =>
		array(
			0 => 'regular',
		),
	'Old Standard TT' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Oldenburg' =>
		array(
			0 => 'regular',
		),
	'Ole' =>
		array(
			0 => 'regular',
		),
	'Oleo Script' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Oleo Script Swash Caps' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Oooh Baby' =>
		array(
			0 => 'regular',
		),
	'Open Sans' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '300italic',
			7 => 'italic',
			8 => '500italic',
			9 => '600italic',
			10 => '700italic',
			11 => '800italic',
		),
	'Oranienbaum' =>
		array(
			0 => 'regular',
		),
	'Orbitron' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
	'Oregano' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Orelega One' =>
		array(
			0 => 'regular',
		),
	'Orienta' =>
		array(
			0 => 'regular',
		),
	'Original Surfer' =>
		array(
			0 => 'regular',
		),
	'Oswald' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Outfit' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Over the Rainbow' =>
		array(
			0 => 'regular',
		),
	'Overlock' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
	'Overlock SC' =>
		array(
			0 => 'regular',
		),
	'Overpass' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Overpass Mono' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Ovo' =>
		array(
			0 => 'regular',
		),
	'Oxanium' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Oxygen' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Oxygen Mono' =>
		array(
			0 => 'regular',
		),
	'PT Mono' =>
		array(
			0 => 'regular',
		),
	'PT Sans' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'PT Sans Caption' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'PT Sans Narrow' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'PT Serif' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'PT Serif Caption' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Pacifico' =>
		array(
			0 => 'regular',
		),
	'Padauk' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Palanquin' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'Palanquin Dark' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Pangolin' =>
		array(
			0 => 'regular',
		),
	'Paprika' =>
		array(
			0 => 'regular',
		),
	'Parisienne' =>
		array(
			0 => 'regular',
		),
	'Passero One' =>
		array(
			0 => 'regular',
		),
	'Passion One' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Passions Conflict' =>
		array(
			0 => 'regular',
		),
	'Pathway Gothic One' =>
		array(
			0 => 'regular',
		),
	'Patrick Hand' =>
		array(
			0 => 'regular',
		),
	'Patrick Hand SC' =>
		array(
			0 => 'regular',
		),
	'Pattaya' =>
		array(
			0 => 'regular',
		),
	'Patua One' =>
		array(
			0 => 'regular',
		),
	'Pavanam' =>
		array(
			0 => 'regular',
		),
	'Paytone One' =>
		array(
			0 => 'regular',
		),
	'Peddana' =>
		array(
			0 => 'regular',
		),
	'Peralta' =>
		array(
			0 => 'regular',
		),
	'Permanent Marker' =>
		array(
			0 => 'regular',
		),
	'Petemoss' =>
		array(
			0 => 'regular',
		),
	'Petit Formal Script' =>
		array(
			0 => 'regular',
		),
	'Petrona' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Philosopher' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Piazzolla' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Piedra' =>
		array(
			0 => 'regular',
		),
	'Pinyon Script' =>
		array(
			0 => 'regular',
		),
	'Pirata One' =>
		array(
			0 => 'regular',
		),
	'Plaster' =>
		array(
			0 => 'regular',
		),
	'Play' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Playball' =>
		array(
			0 => 'regular',
		),
	'Playfair Display' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Playfair Display SC' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
	'Plus Jakarta Sans' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '200italic',
			8 => '300italic',
			9 => 'italic',
			10 => '500italic',
			11 => '600italic',
			12 => '700italic',
			13 => '800italic',
		),
	'Podkova' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Poiret One' =>
		array(
			0 => 'regular',
		),
	'Poller One' =>
		array(
			0 => 'regular',
		),
	'Poly' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Pompiere' =>
		array(
			0 => 'regular',
		),
	'Pontano Sans' =>
		array(
			0 => 'regular',
		),
	'Poor Story' =>
		array(
			0 => 'regular',
		),
	'Poppins' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Port Lligat Sans' =>
		array(
			0 => 'regular',
		),
	'Port Lligat Slab' =>
		array(
			0 => 'regular',
		),
	'Potta One' =>
		array(
			0 => 'regular',
		),
	'Pragati Narrow' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Praise' =>
		array(
			0 => 'regular',
		),
	'Prata' =>
		array(
			0 => 'regular',
		),
	'Preahvihear' =>
		array(
			0 => 'regular',
		),
	'Press Start 2P' =>
		array(
			0 => 'regular',
		),
	'Pridi' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Princess Sofia' =>
		array(
			0 => 'regular',
		),
	'Prociono' =>
		array(
			0 => 'regular',
		),
	'Prompt' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Prosto One' =>
		array(
			0 => 'regular',
		),
	'Proza Libre' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
			8 => '800',
			9 => '800italic',
		),
	'Public Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Puppies Play' =>
		array(
			0 => 'regular',
		),
	'Puritan' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Purple Purse' =>
		array(
			0 => 'regular',
		),
	'Qahiri' =>
		array(
			0 => 'regular',
		),
	'Quando' =>
		array(
			0 => 'regular',
		),
	'Quantico' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Quattrocento' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Quattrocento Sans' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Questrial' =>
		array(
			0 => 'regular',
		),
	'Quicksand' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Quintessential' =>
		array(
			0 => 'regular',
		),
	'Qwigley' =>
		array(
			0 => 'regular',
		),
	'Qwitcher Grypen' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Racing Sans One' =>
		array(
			0 => 'regular',
		),
	'Radio Canada' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Radley' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Rajdhani' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Rakkas' =>
		array(
			0 => 'regular',
		),
	'Raleway' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Raleway Dots' =>
		array(
			0 => 'regular',
		),
	'Ramabhadra' =>
		array(
			0 => 'regular',
		),
	'Ramaraja' =>
		array(
			0 => 'regular',
		),
	'Rambla' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Rammetto One' =>
		array(
			0 => 'regular',
		),
	'Rampart One' =>
		array(
			0 => 'regular',
		),
	'Ranchers' =>
		array(
			0 => 'regular',
		),
	'Rancho' =>
		array(
			0 => 'regular',
		),
	'Ranga' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Rasa' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Rationale' =>
		array(
			0 => 'regular',
		),
	'Ravi Prakash' =>
		array(
			0 => 'regular',
		),
	'Readex Pro' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Recursive' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Red Hat Display' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
			7 => '300italic',
			8 => 'italic',
			9 => '500italic',
			10 => '600italic',
			11 => '700italic',
			12 => '800italic',
			13 => '900italic',
		),
	'Red Hat Mono' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Red Hat Text' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Red Rose' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Redacted' =>
		array(
			0 => 'regular',
		),
	'Redacted Script' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Redressed' =>
		array(
			0 => 'regular',
		),
	'Reem Kufi' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Reem Kufi Fun' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Reem Kufi Ink' =>
		array(
			0 => 'regular',
		),
	'Reenie Beanie' =>
		array(
			0 => 'regular',
		),
	'Reggae One' =>
		array(
			0 => 'regular',
		),
	'Revalia' =>
		array(
			0 => 'regular',
		),
	'Rhodium Libre' =>
		array(
			0 => 'regular',
		),
	'Ribeye' =>
		array(
			0 => 'regular',
		),
	'Ribeye Marrow' =>
		array(
			0 => 'regular',
		),
	'Righteous' =>
		array(
			0 => 'regular',
		),
	'Risque' =>
		array(
			0 => 'regular',
		),
	'Road Rage' =>
		array(
			0 => 'regular',
		),
	'Roboto' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
			11 => '900italic',
		),
	'Roboto Condensed' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
	'Roboto Flex' =>
		array(
			0 => 'regular',
		),
	'Roboto Mono' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '100italic',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
		),
	'Roboto Serif' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Roboto Slab' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Rochester' =>
		array(
			0 => 'regular',
		),
	'Rock Salt' =>
		array(
			0 => 'regular',
		),
	'RocknRoll One' =>
		array(
			0 => 'regular',
		),
	'Rokkitt' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Romanesco' =>
		array(
			0 => 'regular',
		),
	'Ropa Sans' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Rosario' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Rosarivo' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Rouge Script' =>
		array(
			0 => 'regular',
		),
	'Rowdies' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Rozha One' =>
		array(
			0 => 'regular',
		),
	'Rubik' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
			7 => '300italic',
			8 => 'italic',
			9 => '500italic',
			10 => '600italic',
			11 => '700italic',
			12 => '800italic',
			13 => '900italic',
		),
	'Rubik Beastly' =>
		array(
			0 => 'regular',
		),
	'Rubik Bubbles' =>
		array(
			0 => 'regular',
		),
	'Rubik Burned' =>
		array(
			0 => 'regular',
		),
	'Rubik Dirt' =>
		array(
			0 => 'regular',
		),
	'Rubik Distressed' =>
		array(
			0 => 'regular',
		),
	'Rubik Glitch' =>
		array(
			0 => 'regular',
		),
	'Rubik Iso' =>
		array(
			0 => 'regular',
		),
	'Rubik Marker Hatch' =>
		array(
			0 => 'regular',
		),
	'Rubik Maze' =>
		array(
			0 => 'regular',
		),
	'Rubik Microbe' =>
		array(
			0 => 'regular',
		),
	'Rubik Mono One' =>
		array(
			0 => 'regular',
		),
	'Rubik Moonrocks' =>
		array(
			0 => 'regular',
		),
	'Rubik Puddles' =>
		array(
			0 => 'regular',
		),
	'Rubik Wet Paint' =>
		array(
			0 => 'regular',
		),
	'Ruda' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
	'Rufina' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Ruge Boogie' =>
		array(
			0 => 'regular',
		),
	'Ruluko' =>
		array(
			0 => 'regular',
		),
	'Rum Raisin' =>
		array(
			0 => 'regular',
		),
	'Ruslan Display' =>
		array(
			0 => 'regular',
		),
	'Russo One' =>
		array(
			0 => 'regular',
		),
	'Ruthie' =>
		array(
			0 => 'regular',
		),
	'Rye' =>
		array(
			0 => 'regular',
		),
	'STIX Two Text' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => 'italic',
			5 => '500italic',
			6 => '600italic',
			7 => '700italic',
		),
	'Sacramento' =>
		array(
			0 => 'regular',
		),
	'Sahitya' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Sail' =>
		array(
			0 => 'regular',
		),
	'Saira' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Saira Condensed' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Saira Extra Condensed' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Saira Semi Condensed' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Saira Stencil One' =>
		array(
			0 => 'regular',
		),
	'Salsa' =>
		array(
			0 => 'regular',
		),
	'Sanchez' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Sancreek' =>
		array(
			0 => 'regular',
		),
	'Sansita' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '800',
			5 => '800italic',
			6 => '900',
			7 => '900italic',
		),
	'Sansita Swashed' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Sarabun' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
		),
	'Sarala' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Sarina' =>
		array(
			0 => 'regular',
		),
	'Sarpanch' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
	'Sassy Frass' =>
		array(
			0 => 'regular',
		),
	'Satisfy' =>
		array(
			0 => 'regular',
		),
	'Sawarabi Gothic' =>
		array(
			0 => 'regular',
		),
	'Sawarabi Mincho' =>
		array(
			0 => 'regular',
		),
	'Scada' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Scheherazade New' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Schoolbell' =>
		array(
			0 => 'regular',
		),
	'Scope One' =>
		array(
			0 => 'regular',
		),
	'Seaweed Script' =>
		array(
			0 => 'regular',
		),
	'Secular One' =>
		array(
			0 => 'regular',
		),
	'Sedgwick Ave' =>
		array(
			0 => 'regular',
		),
	'Sedgwick Ave Display' =>
		array(
			0 => 'regular',
		),
	'Sen' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '800',
		),
	'Send Flowers' =>
		array(
			0 => 'regular',
		),
	'Sevillana' =>
		array(
			0 => 'regular',
		),
	'Seymour One' =>
		array(
			0 => 'regular',
		),
	'Shadows Into Light' =>
		array(
			0 => 'regular',
		),
	'Shadows Into Light Two' =>
		array(
			0 => 'regular',
		),
	'Shalimar' =>
		array(
			0 => 'regular',
		),
	'Shanti' =>
		array(
			0 => 'regular',
		),
	'Share' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Share Tech' =>
		array(
			0 => 'regular',
		),
	'Share Tech Mono' =>
		array(
			0 => 'regular',
		),
	'Shippori Antique' =>
		array(
			0 => 'regular',
		),
	'Shippori Antique B1' =>
		array(
			0 => 'regular',
		),
	'Shippori Mincho' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Shippori Mincho B1' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Shojumaru' =>
		array(
			0 => 'regular',
		),
	'Short Stack' =>
		array(
			0 => 'regular',
		),
	'Shrikhand' =>
		array(
			0 => 'regular',
		),
	'Siemreap' =>
		array(
			0 => 'regular',
		),
	'Sigmar One' =>
		array(
			0 => 'regular',
		),
	'Signika' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Signika Negative' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Silkscreen' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Simonetta' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '900',
			3 => '900italic',
		),
	'Single Day' =>
		array(
			0 => 'regular',
		),
	'Sintony' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Sirin Stencil' =>
		array(
			0 => 'regular',
		),
	'Six Caps' =>
		array(
			0 => 'regular',
		),
	'Skranji' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Slabo 13px' =>
		array(
			0 => 'regular',
		),
	'Slabo 27px' =>
		array(
			0 => 'regular',
		),
	'Slackey' =>
		array(
			0 => 'regular',
		),
	'Smokum' =>
		array(
			0 => 'regular',
		),
	'Smooch' =>
		array(
			0 => 'regular',
		),
	'Smooch Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Smythe' =>
		array(
			0 => 'regular',
		),
	'Sniglet' =>
		array(
			0 => 'regular',
			1 => '800',
		),
	'Snippet' =>
		array(
			0 => 'regular',
		),
	'Snowburst One' =>
		array(
			0 => 'regular',
		),
	'Sofadi One' =>
		array(
			0 => 'regular',
		),
	'Sofia' =>
		array(
			0 => 'regular',
		),
	'Solway' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '800',
		),
	'Song Myung' =>
		array(
			0 => 'regular',
		),
	'Sonsie One' =>
		array(
			0 => 'regular',
		),
	'Sora' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Sorts Mill Goudy' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Source Code Pro' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Source Sans 3' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Source Sans Pro' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
			11 => '900italic',
		),
	'Source Serif 4' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
			7 => '900',
			8 => '200italic',
			9 => '300italic',
			10 => 'italic',
			11 => '500italic',
			12 => '600italic',
			13 => '700italic',
			14 => '800italic',
			15 => '900italic',
		),
	'Source Serif Pro' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
			11 => '900italic',
		),
	'Space Grotesk' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Space Mono' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Special Elite' =>
		array(
			0 => 'regular',
		),
	'Spectral' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
			12 => '800',
			13 => '800italic',
		),
	'Spectral SC' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '600',
			9 => '600italic',
			10 => '700',
			11 => '700italic',
			12 => '800',
			13 => '800italic',
		),
	'Spicy Rice' =>
		array(
			0 => 'regular',
		),
	'Spinnaker' =>
		array(
			0 => 'regular',
		),
	'Spirax' =>
		array(
			0 => 'regular',
		),
	'Splash' =>
		array(
			0 => 'regular',
		),
	'Spline Sans' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Spline Sans Mono' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Squada One' =>
		array(
			0 => 'regular',
		),
	'Square Peg' =>
		array(
			0 => 'regular',
		),
	'Sree Krushnadevaraya' =>
		array(
			0 => 'regular',
		),
	'Sriracha' =>
		array(
			0 => 'regular',
		),
	'Srisakdi' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Staatliches' =>
		array(
			0 => 'regular',
		),
	'Stalemate' =>
		array(
			0 => 'regular',
		),
	'Stalinist One' =>
		array(
			0 => 'regular',
		),
	'Stardos Stencil' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Stick' =>
		array(
			0 => 'regular',
		),
	'Stick No Bills' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Stint Ultra Condensed' =>
		array(
			0 => 'regular',
		),
	'Stint Ultra Expanded' =>
		array(
			0 => 'regular',
		),
	'Stoke' =>
		array(
			0 => '300',
			1 => 'regular',
		),
	'Strait' =>
		array(
			0 => 'regular',
		),
	'Style Script' =>
		array(
			0 => 'regular',
		),
	'Stylish' =>
		array(
			0 => 'regular',
		),
	'Sue Ellen Francisco' =>
		array(
			0 => 'regular',
		),
	'Suez One' =>
		array(
			0 => 'regular',
		),
	'Sulphur Point' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Sumana' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Sunflower' =>
		array(
			0 => '300',
			1 => '500',
			2 => '700',
		),
	'Sunshiney' =>
		array(
			0 => 'regular',
		),
	'Supermercado One' =>
		array(
			0 => 'regular',
		),
	'Sura' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Suranna' =>
		array(
			0 => 'regular',
		),
	'Suravaram' =>
		array(
			0 => 'regular',
		),
	'Suwannaphum' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'Swanky and Moo Moo' =>
		array(
			0 => 'regular',
		),
	'Syncopate' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Syne' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Syne Mono' =>
		array(
			0 => 'regular',
		),
	'Syne Tactile' =>
		array(
			0 => 'regular',
		),
	'Tai Heritage Pro' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Tajawal' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Tangerine' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Tapestry' =>
		array(
			0 => 'regular',
		),
	'Taprom' =>
		array(
			0 => 'regular',
		),
	'Tauri' =>
		array(
			0 => 'regular',
		),
	'Taviraj' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Teko' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Telex' =>
		array(
			0 => 'regular',
		),
	'Tenali Ramakrishna' =>
		array(
			0 => 'regular',
		),
	'Tenor Sans' =>
		array(
			0 => 'regular',
		),
	'Text Me One' =>
		array(
			0 => 'regular',
		),
	'Texturina' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Thasadith' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'The Girl Next Door' =>
		array(
			0 => 'regular',
		),
	'The Nautigal' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Tienne' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Tillana' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Timmana' =>
		array(
			0 => 'regular',
		),
	'Tinos' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Tiro Bangla' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Devanagari Hindi' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Devanagari Marathi' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Devanagari Sanskrit' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Gurmukhi' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Kannada' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Tamil' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Tiro Telugu' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Titan One' =>
		array(
			0 => 'regular',
		),
	'Titillium Web' =>
		array(
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
		),
	'Tomorrow' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Tourney' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Trade Winds' =>
		array(
			0 => 'regular',
		),
	'Train One' =>
		array(
			0 => 'regular',
		),
	'Trirong' =>
		array(
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
	'Trispace' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
		),
	'Trocchi' =>
		array(
			0 => 'regular',
		),
	'Trochut' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
	'Truculenta' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Trykker' =>
		array(
			0 => 'regular',
		),
	'Tulpen One' =>
		array(
			0 => 'regular',
		),
	'Turret Road' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
		),
	'Twinkle Star' =>
		array(
			0 => 'regular',
		),
	'Ubuntu' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '700',
			7 => '700italic',
		),
	'Ubuntu Condensed' =>
		array(
			0 => 'regular',
		),
	'Ubuntu Mono' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Uchen' =>
		array(
			0 => 'regular',
		),
	'Ultra' =>
		array(
			0 => 'regular',
		),
	'Uncial Antiqua' =>
		array(
			0 => 'regular',
		),
	'Underdog' =>
		array(
			0 => 'regular',
		),
	'Unica One' =>
		array(
			0 => 'regular',
		),
	'UnifrakturCook' =>
		array(
			0 => '700',
		),
	'UnifrakturMaguntia' =>
		array(
			0 => 'regular',
		),
	'Unkempt' =>
		array(
			0 => 'regular',
			1 => '700',
		),
	'Unlock' =>
		array(
			0 => 'regular',
		),
	'Unna' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Updock' =>
		array(
			0 => 'regular',
		),
	'Urbanist' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'VT323' =>
		array(
			0 => 'regular',
		),
	'Vampiro One' =>
		array(
			0 => 'regular',
		),
	'Varela' =>
		array(
			0 => 'regular',
		),
	'Varela Round' =>
		array(
			0 => 'regular',
		),
	'Varta' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
	'Vast Shadow' =>
		array(
			0 => 'regular',
		),
	'Vazirmatn' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Vesper Libre' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
	'Viaoda Libre' =>
		array(
			0 => 'regular',
		),
	'Vibes' =>
		array(
			0 => 'regular',
		),
	'Vibur' =>
		array(
			0 => 'regular',
		),
	'Vidaloka' =>
		array(
			0 => 'regular',
		),
	'Viga' =>
		array(
			0 => 'regular',
		),
	'Voces' =>
		array(
			0 => 'regular',
		),
	'Volkhov' =>
		array(
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
	'Vollkorn' =>
		array(
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
			10 => '800italic',
			11 => '900italic',
		),
	'Vollkorn SC' =>
		array(
			0 => 'regular',
			1 => '600',
			2 => '700',
			3 => '900',
		),
	'Voltaire' =>
		array(
			0 => 'regular',
		),
	'Vujahday Script' =>
		array(
			0 => 'regular',
		),
	'Waiting for the Sunrise' =>
		array(
			0 => 'regular',
		),
	'Wallpoet' =>
		array(
			0 => 'regular',
		),
	'Walter Turncoat' =>
		array(
			0 => 'regular',
		),
	'Warnes' =>
		array(
			0 => 'regular',
		),
	'Water Brush' =>
		array(
			0 => 'regular',
		),
	'Waterfall' =>
		array(
			0 => 'regular',
		),
	'Wellfleet' =>
		array(
			0 => 'regular',
		),
	'Wendy One' =>
		array(
			0 => 'regular',
		),
	'Whisper' =>
		array(
			0 => 'regular',
		),
	'WindSong' =>
		array(
			0 => 'regular',
			1 => '500',
		),
	'Wire One' =>
		array(
			0 => 'regular',
		),
	'Work Sans' =>
		array(
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
			9 => '100italic',
			10 => '200italic',
			11 => '300italic',
			12 => 'italic',
			13 => '500italic',
			14 => '600italic',
			15 => '700italic',
			16 => '800italic',
			17 => '900italic',
		),
	'Xanh Mono' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Yaldevi' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Yanone Kaffeesatz' =>
		array(
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
	'Yantramanav' =>
		array(
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Yatra One' =>
		array(
			0 => 'regular',
		),
	'Yellowtail' =>
		array(
			0 => 'regular',
		),
	'Yeon Sung' =>
		array(
			0 => 'regular',
		),
	'Yeseva One' =>
		array(
			0 => 'regular',
		),
	'Yesteryear' =>
		array(
			0 => 'regular',
		),
	'Yomogi' =>
		array(
			0 => 'regular',
		),
	'Yrsa' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '300italic',
			6 => 'italic',
			7 => '500italic',
			8 => '600italic',
			9 => '700italic',
		),
	'Yuji Boku' =>
		array(
			0 => 'regular',
		),
	'Yuji Mai' =>
		array(
			0 => 'regular',
		),
	'Yuji Syuku' =>
		array(
			0 => 'regular',
		),
	'Yusei Magic' =>
		array(
			0 => 'regular',
		),
	'ZCOOL KuaiLe' =>
		array(
			0 => 'regular',
		),
	'ZCOOL QingKe HuangYou' =>
		array(
			0 => 'regular',
		),
	'ZCOOL XiaoWei' =>
		array(
			0 => 'regular',
		),
	'Zen Antique' =>
		array(
			0 => 'regular',
		),
	'Zen Antique Soft' =>
		array(
			0 => 'regular',
		),
	'Zen Dots' =>
		array(
			0 => 'regular',
		),
	'Zen Kaku Gothic Antique' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '900',
		),
	'Zen Kaku Gothic New' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '900',
		),
	'Zen Kurenaido' =>
		array(
			0 => 'regular',
		),
	'Zen Loop' =>
		array(
			0 => 'regular',
			1 => 'italic',
		),
	'Zen Maru Gothic' =>
		array(
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '900',
		),
	'Zen Old Mincho' =>
		array(
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Zen Tokyo Zoo' =>
		array(
			0 => 'regular',
		),
	'Zeyada' =>
		array(
			0 => 'regular',
		),
	'Zhi Mang Xing' =>
		array(
			0 => 'regular',
		),
	'Zilla Slab' =>
		array(
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
	'Zilla Slab Highlight' =>
		array(
			0 => 'regular',
			1 => '700',
		),
);