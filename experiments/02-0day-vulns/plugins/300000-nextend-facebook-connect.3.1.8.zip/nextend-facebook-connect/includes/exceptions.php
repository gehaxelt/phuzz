<?php

class NSLContinuePageRenderException extends Exception {

}