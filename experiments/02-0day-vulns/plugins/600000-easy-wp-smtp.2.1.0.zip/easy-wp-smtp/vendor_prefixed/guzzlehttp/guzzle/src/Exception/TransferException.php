<?php

namespace EasyWPSMTP\Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \EasyWPSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
