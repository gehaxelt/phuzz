<?php

// This file is used only on first installation!

$options = array();
$options['ip_blacklist'] = array();
$options['address_blacklist'] = array();
$options['antiflood'] = 60;
$options['akismet'] = 0;
$options['captcha'] = 0;
$options['disabled'] = 0;