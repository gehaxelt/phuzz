<?php

$options = array(
    'enabled' => 0,
    'host' => '',
    'user' => '',
    'pass' => '',
    'port' => 25,
    'secure' => '',
    'ssl_insecure' => 0
);
