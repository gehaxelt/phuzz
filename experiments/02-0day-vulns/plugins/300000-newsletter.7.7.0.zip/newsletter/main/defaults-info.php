<?php

$options = array(
    'header_logo' => array('id'=>0),
    'header_title' => get_bloginfo('name'),
    'header_sub' => get_bloginfo('description'),
    'footer_title' => '',
    'footer_contact' => '',
    'footer_legal' => '',
    'facebook_url' => '',
    'twitter_url' => '',
    'instagram_url' => '',
    'pinterest_url' => '',
    'linkedin_url' => '',
    'tumblr_url' => '',
    'youtube_url' => '',
    'vimeo_url' => '',
    'soundcloud_url' => '',
    'telegram_url' => '',
    'vk_url' => ''
);
