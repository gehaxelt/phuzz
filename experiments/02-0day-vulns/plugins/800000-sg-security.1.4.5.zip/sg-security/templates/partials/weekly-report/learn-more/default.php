<tr>
    <td class="body-text"
        style="color: #444444; font-style: italic; font-weight: 400; font-family: 'Open Sans', Arial, Helvetica, sans-serif; font-size: 16px; line-height: 26px; padding: 0px 0 25px 0">
        <?php echo $args['email_body']['learn_more']; ?><a href="https://www.siteground.com/tutorials/wordpress/sg-security/activity-log/" target="_blank" rel="noreferrer" style="color: #22b8d1; text-decoration: none;"><?php echo $args['email_body']['learn_more_link']; ?></a><?php echo $args['email_body']['article']; ?>
    </td>
</tr>