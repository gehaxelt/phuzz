<?php

namespace WhichBrowser\Data;

Applications::$OTHERS_REGEX = '/(itunes|qt|bluefish|nightingale|songbird|stagefright|substream|vlc|windows-media|coreplayer|flycast|boxee|kodi|xbmc|lightning|thunderbird|outlook|lotus|postbox|bat|yahoo|daum|flipboard|akregator|blogos|cococ|feed|liferea|news|jetbrains|rss|reeder|reedkit|rome|ziepod|messenger|kakao|kik|line|slack|viber|whatsapp|wire|yammer|zalo|fbios|fb4a|googleplus|instagram|pinterest|weibo|tumblr|twitter|wp-android|yelp|office|bingweb|hao123|gsa|naver|sogousearch|yandex|atom|golive|brackets|iweb|frontpage|amaya|websphere|download|tansodl|origin|secondlife|valve|raptr|alipay|cooliris|google|leechcraft|expeditor)/i';
