<?php

return [
    'email',
    'successmessage',
    'redirect',
    'save',
    'deletedatarequest',
    'exportdatarequest',
];
