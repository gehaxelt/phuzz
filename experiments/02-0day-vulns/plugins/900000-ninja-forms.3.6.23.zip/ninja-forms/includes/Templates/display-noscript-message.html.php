<noscript class="ninja-forms-noscript-message">
	<?php echo esc_html( $message ); ?>
</noscript>
