<?php if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class NF_Abstracts_Element
 */
abstract class NF_Abstracts_Element
{

}