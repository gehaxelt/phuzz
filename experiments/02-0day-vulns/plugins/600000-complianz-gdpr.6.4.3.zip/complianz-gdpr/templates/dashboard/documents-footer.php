<div class="cmplz-legend"><?php echo cmplz_icon('circle-check', 'success')?><span><?php _e("Validated", "complianz-gdpr")?></span></div>
<div class="cmplz-legend"><?php echo cmplz_icon('sync', 'success')?><span><?php _e("Synchronized", "complianz-gdpr")?></span></div>
<div class="cmplz-legend"><?php echo cmplz_icon('shortcode', 'default')?><span><?php _e("Shortcode", "complianz-gdpr")?></span></div>
