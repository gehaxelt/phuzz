<div class="cmplz-footer-contents">
	<button class="button button-primary" type="submit"><?php echo __( 'Save', 'complianz-gdpr' ) ?></button>
</div>
