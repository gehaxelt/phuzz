<div class="name-header">
	<h5><?php _e( 'Name', 'complianz-gdpr' ) ?></h5>
</div>
<div class="name">{link_open}{name}{link_close}</div>
<div class="retention-header">
	<h5><?php _e( 'Expiration', 'complianz-gdpr' ) ?></h5>
</div>
<div class="retention">{retention}</div>
<div class="function-header">
	<h5><?php _e( 'Function', 'complianz-gdpr' ) ?></h5>
</div>
<div class="function">{cookieFunction}</div>
