<div class="cmplz-step">
    <div class="cmplz-step-header {active} {completed}"><a href="{url}"><h2>{title}</h2></a></div>
    {sections}
</div>
