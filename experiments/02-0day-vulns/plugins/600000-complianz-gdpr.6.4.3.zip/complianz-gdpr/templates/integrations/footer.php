
<div class="cmplz-footer-contents">
	<button class="button button-primary" type="submit"><?php echo __( 'Save', 'complianz-gdpr' ) ?></button>
</div>
<div class="cmplz-hidden">
	<div class="cmplz-paging-next-icon">
		<?php echo cmplz_icon('chevron-right', 'success');?>
	</div>
	<div class="cmplz-paging-prev-icon">
		<?php echo cmplz_icon('chevron-left', 'success');?>
	</div>
</div>
