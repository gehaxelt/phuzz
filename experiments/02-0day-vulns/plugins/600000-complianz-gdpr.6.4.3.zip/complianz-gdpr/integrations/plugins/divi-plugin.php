<?php
defined( 'ABSPATH' ) or die( "you do not have access to this page!" );
//is the same for divi.
require_once( __DIR__.'/divi.php' );
