<div class="cmplz-grid-container grid-active {class}" data-id="{index}" data-template="{name}" {conditions}>
	<div class="cmplz-grid-header">
		<h2 class="cmplz-grid-title h4">{header}</h2>
		<div class="cmplz-grid-controls">{controls}</div>
	</div>
	<div class="cmplz-grid-content">{body}</div>
	<div class="cmplz-grid-footer">{footer}</div>
</div>
